
var score=0;
var backgorund;
var monkey;
var ground;
var obstaclesgroup,obstacles;
var bananagroup,banana;
var background;

function preload() {
background = loadImage("jungle.png.png");
monkey = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png",
"Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png",
  "Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  banana=loadImage("banana.png");
  obstacle=loadImage("stone.png");
  background = loadImage("junglepng.png");
}


function setup() {
  createCanvas(400, 400);
  
  
 stroke("white");
textSize(20);
fill("white");
text("score: "+ score, 500,50);
 

monkey = createSprite(80,330,10,10); 
monkey.addAnimation ("monkeyrunning",monkey);
ground = createSprite(200,395,400,10);
ground.velocityX=-4;
ground.visible=false;
  
  
  
  background = addImage("back",background);
  background.velocityX=-4;
  

  
  bananagroup = newGroup();
  obstaclesgroup = newGroup();
}


function draw() {
  background(220);
  
   if (background.x < 0){
    background.x = background.width/2;
  }
  
   if (ground.x < 0){
    ground.x =ground.width/2;
  }
  
   if(keyDown("space") && monkey.y >= 300){
      monkey.velocityY = -15 ;
    }
    monkey.velocityY = monkey.velocityY + 0.8;
    
    monkey.collide(ground);
  
  if (bananagroup.isTouching(monkey)) {
  score = score+2;
    
}
  
  
  if (obstaclesgroup.isTouching(monkey)) {
  scale = 0.5
    
}
     
  spawnObstacles();
  bananas();
  
  
  switch(score){
    
    case 10:monkey.scale = 0.12;   
           break;
    case 20:monkey.scale = 0.14; 
           break;
    case 30:monkey.scale = 0.16;   
          break;
    case 40:monkey.scale = 0.18;   
          break;
    deafult:break;  
  }     
  

drawSprites();
  
}


function spawnObstacles() {
    if(FrameCount % 300 === 0) {
     obstacle = createSprite(400,365,10,40);
      obstacle.velocityX = -6;
      //generate random obstacles
      obstacle.addImage("Stone");
      //assign scale and lifetime to the obstacle           
      obstacle.scale = 0.2;
      obstacle.lifetime = 70;
      //add each obstacle to the group
      Obstaclesgroup.add(obstacle);
    }
  }

function bananas() {
  if(FrameCount % 80 === 0) {
    var banana = createSprite(400,365,10,40);
    banana.velocityX = -6;
    banana.y = randomNumber(120,200);
    //generate random obstacles
    banana.addImage("Bananas",bananaimage);
    
    //assign scale and lifetime to the obstacle           
    banana.scale = 0.1;
    banana.lifetime = 70;
    //add each obstacle to the group
    bananagroup.add(banana);
    monkey.depth=banana.depth+1;
  }
}